/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cau_lac_bo_bong_da;

/**
 *
 * @author Nguyen Cong Van
 */
public class OutPut {
    String code, name;
    int turnevor;
    
    public String toString() {
        return code + " " + name + " " + turnevor;
    }
}
