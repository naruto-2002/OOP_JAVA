/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xau_con_lon_nhat;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        int l = s.length();
        int[] arr = new int[l + 5];
        for(int i = 0; i < l; i++) {
            arr[i] = s.charAt(i);
        }
        
        for(int i = 0; i < l - 1; i++) {
            if(arr[i] < arr[i + 1]) {
                if(i > 0) {
                    int j = i;
                    while(j-- > 0) {
                        if(arr[j] == arr[i]) arr[j] = 0;
                        if(arr[j] != 0 && arr[j] != arr[i]) break;
                    }
                }
                arr[i] = 0;
            }
        }
        
        String res = "";
        for(int i = 0; i < l; i++) {
            if(arr[i] != 0) {
                res += s.charAt(i);
            }
        }
        
        System.out.println(res);
    }
}
