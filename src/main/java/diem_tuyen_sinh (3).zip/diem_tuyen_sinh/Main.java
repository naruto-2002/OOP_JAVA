/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diem_tuyen_sinh;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("D:\\Documents\\nam_3_ki_1\\lap_trinh_huong_doi_tuong_java\\CodePtit\\src\\main\\java\\diem_tuyen_sinh\\THISINH.in"));
        int t = sc.nextInt();
        ArrayList<Student> res = new ArrayList<>();
        while(t-- > 0) {
            sc.nextLine();
            Student hs = new Student(sc.nextLine(), sc.nextInt(), sc.next(), sc.nextInt());
            res.add(hs);
        }
        Collections.sort(res, (Student hs1, Student hs2) -> {
            if(hs1.getTotal().compareTo(hs2.getTotal()) < 0) return 1;
            else if(hs1.getTotal().compareTo(hs2.getTotal()) == 0) {
                if(hs1.code.compareTo(hs2.code) > 0) return 1;
            }
            return -1;
        });
        for(Student hs: res) {
            System.out.println(hs);
        }
    }
}
