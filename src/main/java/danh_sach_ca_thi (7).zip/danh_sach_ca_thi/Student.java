/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danh_sach_ca_thi;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Student implements Comparable<Student> {
    String code, date, hour, id;
    
    static int cnt = 1;
    
    Student(Scanner sc) {
        code = "C0" + (cnt < 10? '0' + Integer.toString(cnt) : Integer.toString(cnt));
        cnt++;
        date = sc.nextLine();
        hour = sc.nextLine();
        id = sc.nextLine();
    }
    
    public String toString() {
        return code + " " + date + " " + hour + " " + id;
    }
    
    public int compareTo(Student o) {
        
//                if(o1.getDate().equals(o2.getDate())){
//                    if(o1.getHour() == o2.getHour())
//                        return o1.getMinute() - o2.getMinute();
//                    return o1.getHour() - o2.getHour();
//                }else{
//                    if(o1.getYear() == o2.getYear()){
//                        if(o1.getMonth() == o2.getMonth())
//                            return o1.getDay() - o2.getDay();
//                        return o1.getMonth() - o2.getMonth();
//                    }else
//                        return o1.getYear() - o2.getYear();
//                }
           if(date.equals(o.date)) {
               return hour.compareTo(o.hour);
           }else {
               return date.compareTo(o.date);
           }
           
          
        
    }
    
}
