/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danh_sach_ca_thi;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Student implements Comparable<Student> {
    String code, date, hour, id;
    
    static int cnt = 1;
    
    Student(Scanner sc) {
        code = "C0" + (cnt < 10? '0' + Integer.toString(cnt) : Integer.toString(cnt));
        cnt++;
        date = sc.nextLine();
        hour = sc.nextLine();
        id = sc.nextLine();
    }
    
    public String toString() {
        return code + " " + date + " " + hour + " " + id;
    }
    
    public int compareTo(Student o) {
        if(date.compareTo(o.date) > 0) return 1;
        if(date.compareTo(o.date) < 0) return -1;
        return hour.compareTo(o.hour);
    }
    
}
