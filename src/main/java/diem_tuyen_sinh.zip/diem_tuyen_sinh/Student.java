/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diem_tuyen_sinh;

/**
 *
 * @author Nguyen Cong Van
 */
public class Student {
    String code, name, ethnic;
    float point;
    int area;
    
    static int cnt = 1;
    
    Student(String name, int point, String ethnic, int area) {
        code = "TS" + (cnt < 10? '0' + Integer.toString(cnt): Integer.toString(cnt));
        cnt++;
        this.name = formName(name);
        this.point = point;
        this.ethnic = ethnic;
        this.area = area;
    }
    
    String formName(String s) {
        String[] ans = s.trim().toLowerCase().split("\\s+");
        String res = "";
        for(String ss: ans) {
            res += ss.substring(0, 1).toUpperCase() + ss.substring(1) + " ";
        }
        return res.substring(0, res.length() - 1);
    }
    
    float getPriority1() {
        switch(area) {
            case 1:
                return (float) 1.5;
            case 2:
                return (float) 1.0;
            case 3:
                return (float) 0.0;
            default:
                return (float) 1.5;
        }
    }
    
    float getPriority2() {
        if(ethnic.equals("Kinh")) return (float) 0.0;
        else return (float) 1.5;
    }
    
    String getTotal() {
        return String.format("%.1f", point + getPriority1() + getPriority2());
    }
    
    String getRank() {
        if(getTotal().compareTo("20.5") >= 0) return "Do";
        else return "Truot";
    }
    
    public String toString() {
        return code + " " + name + " " + getTotal() + " " + getRank();
    }
}
