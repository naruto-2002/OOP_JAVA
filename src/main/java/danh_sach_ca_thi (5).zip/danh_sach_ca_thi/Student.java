/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package danh_sach_ca_thi;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Student implements Comparable<Student> {
    String code, date, hour, id;
    
    static int cnt = 1;
    
    Student(Scanner sc) {
        code = "C0" + (cnt < 10? '0' + Integer.toString(cnt) : Integer.toString(cnt));
        cnt++;
        date = sc.nextLine();
        hour = sc.nextLine();
        id = sc.nextLine();
    }
    
    public String toString() {
        return code + " " + date + " " + hour + " " + id;
    }
    
    public int compareTo(Student o) {
        String[] ans1 = date.split("/");
        String[] ans2 = o.date.split("/");
        if(ans1[2].compareTo(ans2[2]) > 0) return 1;
        if(ans1[2].compareTo(ans2[2]) < 0) return -1;
        if(ans1[1].compareTo(ans2[1]) > 0) return 1;
        if(ans1[1].compareTo(ans2[1]) < 0) return -1;
        if(ans1[0].compareTo(ans2[0]) > 0) return 1;
        if(ans1[0].compareTo(ans2[0]) < 0) return -1;
        return hour.compareTo(o.hour);
    }
    
}
