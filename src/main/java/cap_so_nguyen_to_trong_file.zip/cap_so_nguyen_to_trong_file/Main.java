/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cap_so_nguyen_to_trong_file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    static int[] f = new int[10000];
    public static void slove() {
        Arrays.fill(f, 1);
        f[0] = f[1] = 0;
        for(int i = 2; i < 10000; i++) {
            if(f[i] == 1) {
                for(int j = 2*i; j < 10000; j += i) {
                    f[j] = 0;
                }
            }
        }
    }
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        slove();
//        Scanner sc = new Scanner(System.in);
//        int t = sc.nextInt();
//        List<Integer> l = new ArrayList<>();
//        while(t-- > 0) {
//            int a = sc.nextInt();
//            l.add(a);
//        }
//        IOFile.write("src\\main\\java\\cap_so_nguyen_to_trong_file\\SONGUYEN.in", l);
        List<Integer> l1 = IOFile.resad("SONGUYEN.in");
        
        int[] cnt = new int[10000];
        for(Integer i: l1) {
            cnt[i] += f[i];
        }
        
        for(int i = 0; i < 10000; i++) {
            if(cnt[i] > 0) {
                System.out.println(i + " " + cnt[i]);
            }
        }
        
        
        
        
    }
}
