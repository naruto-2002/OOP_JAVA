/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nhap_xuat_hang;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Statistic {
    String code;
    int inp, price, outp; 
    
    void input(Scanner sc) {
        code = sc.next();
        inp = sc.nextInt();
        price = sc.nextInt();
        outp = sc.nextInt();
    }
    
    
}
