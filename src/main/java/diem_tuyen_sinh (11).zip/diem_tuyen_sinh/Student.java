/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package diem_tuyen_sinh;

/**
 *
 * @author Nguyen Cong Van
 */
public class Student implements Comparable<Student> {
    String code, name, ethnic;
    float point;
    int area;
    
    static int cnt = 1;
    
    Student(String name, float point, String ethnic, int area) {
        code = "TS" + (cnt < 10? '0' + Integer.toString(cnt): Integer.toString(cnt));
        cnt++;
        this.name = formName(name);
        this.point = point;
        this.ethnic = ethnic;
        this.area = area;
    }
    
    String formName(String s) {
        String[] ans = s.trim().toLowerCase().split("\\s+");
        String res = "";
        for(String ss: ans) {
            res += ss.substring(0, 1).toUpperCase() + ss.substring(1) + " ";
        }
        return res.substring(0, res.length() - 1);
    }
    
    float getPriority1() {
        switch(area) {
            case 1:
                return (float) 1.5;
            case 2:
                return (float) 1.0;
            default:
                return (float) 0.0;
        }
    }
    
    float getPriority2() {
        if(ethnic.contentEquals("Kinh")) return (float) 0.0;
        else return (float) 1.5;
    }
    
    float getTotal() {
        return point + getPriority1() + getPriority2();
    }
    
    String getRank() {
        if(point + getPriority1() + getPriority2() >= 20.5 ) return "Do";
        else return "Truot";
    }
    
    public String toString() {
        return code + " " + name + " " + String.format("%.1f", getTotal()) + " " + getRank();
    }
    
    @Override
    public int compareTo(Student o) {
        if(getTotal() < o.getTotal()) return 1;
        if(getTotal() > o.getTotal()) return -1;
        return this.code.compareTo(o.code);
    }
}
