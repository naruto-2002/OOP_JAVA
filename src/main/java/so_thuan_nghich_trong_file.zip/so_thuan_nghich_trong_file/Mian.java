/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package so_thuan_nghich_trong_file;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

/**
 *
 * @author Nguyen Cong Van
 */
public class Mian {
    public static boolean KT(int n) {
        int tmp = n, m = 0;
        int cnt = 0;
        while(n > 0) {
            if((n%10)%2 == 0) return false;
            m = m*10 + n%10;
            n /= 10;
            cnt += 1;
        }
        if(tmp != m) return false;
        if(cnt < 2 || cnt%2 == 0) return false;
        return true;
    }
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        List<Integer> l1 = IOFile.read("DATA1.in");
        List<Integer> l2 = IOFile.read("DATA2.in");
        
        Collections.sort(l1);
        
        TreeMap<Integer, Integer> res = new TreeMap<>();
        for(Integer i: l1) {
            if(KT(i) == true && l2.contains(i) == true) {
                int cnt = 0;
                for(Integer j: l1) {
                    if(i == j) cnt += 1;
                }
                for(Integer j: l2) {
                    if(i == j) cnt += 1;
                }
                res.put(i, cnt);
            }
            if(res.size() == 10) break;
        }
        
        for(Integer i: res.keySet()) {
            System.out.println(i + " " + res.get(i));
        }
    }
}
