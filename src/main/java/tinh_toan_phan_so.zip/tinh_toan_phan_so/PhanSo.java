/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tinh_toan_phan_so;

/**
 *
 * @author Nguyen Cong Van
 */
public class PhanSo {
    private int tu, mau;

    public PhanSo() {
    }

    public PhanSo(int tu, int mau) {
        this.tu = tu;
        this.mau = mau;
        setTu(this.tu/gcd(tu, mau));
        setMau(this.mau/gcd(tu, mau));
    }

    public int getTu() {
        return tu;
    }

    public void setTu(int tu) {
        this.tu = tu;
    }

    public int getMau() {
        return mau;
    }

    public void setMau(int mau) {
        this.mau = mau;
    }
    
    private int gcd(int a, int b) {
        while(a*b != 0) {
            if(a > b) {
                a %= b;
            }else {
                b %= a;
            }
        }
        return a + b;
    }
    
    
    
    public String toString() {
        String s = Integer.toString(tu) + "/" + Integer.toString(mau);
        return s;
    }
}
