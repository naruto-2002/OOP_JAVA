/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ten_viet_tat;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Teacher {
    String name;
    
    Teacher(Scanner sc) {
        name = sc.nextLine();
    }
    
    String getSummary() {
        String[] ans = name.split("\\s+");
        String res = "";
        for(String s: ans) {
            res += s.substring(0, 1) + '.';
        }
        return res.substring(0, res.length() - 1);
    }
    
    String getName() {
        String[] ans = name.split("\\s+");
        String res = "";
        for(int i = 1; i < ans.length; i++) {
            res += ans[i] + ' ';
        }
        return res.substring(0, res.length() - 1);
    }
    
    String getSurname() {
        String[] ans = name.split("\\s+");
        return ans[0];
    }
    
    public String toString() {
        return name;
    }
}
