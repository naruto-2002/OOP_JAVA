/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lop_hoc_phan_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<Subject> res = new ArrayList<>();
        while(t-- > 0) {
            Subject mh = new Subject();
            mh.input(sc);
            res.add(mh);
        }
        Collections.sort(res, (Subject mh1, Subject mh2) -> {
            if(mh1.group.compareTo(mh2.group) > 0) return 1;
            return -1;
        });
        int tt = sc.nextInt();
        while(tt-- > 0) {
            String s = sc.next();
            for(Subject mh: res) {
                if(s.compareTo(mh.code) == 0){
                    System.out.println("Danh sach nhom lop mon " + mh.name + ':');
                    break;
                }
            }
            for(Subject mh: res) {
                if(s.compareTo(mh.code) == 0){
                    System.out.println(mh);
                }
            }
        }
    }
    
}
/*
4
THCS2D20
Tin hoc co so 2 - D20
01
Nguyen Binh An
CPPD20
Ngon ngu lap trinh C++ - D20
01
Le Van Cong
THCS2D20
Tin hoc co so 2 - D20
02
Nguyen Trung Binh
LTHDTD19
Lap trinh huong doi tuong - D19
01
Nguyen Binh An
1
THCS2D20
*/