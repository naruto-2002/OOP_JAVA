/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day_con_lien_tiep_co_tong_bang_k;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t = sc.nextInt();
        while(t-- > 0) {
            int n = sc.nextInt(), k = sc.nextInt();
            int[] arr = new int[n];
            for(int i = 0; i < n; i++) {
                arr[i] = sc.nextInt();
            }
            
            int ok = 0;
            for(int i = 0; i < n; i++) {
                int sum = 0;
                for(int j = i; j < n; j++) {
                    sum += arr[j];
                    if(sum == k) {
                        ok = 1;
                        break;
                    }
                    if(sum > k && arr[j] > k) {
                        break;
                    }
                }
                if(ok == 1) break;
            }
            if(ok == 1) System.out.println("YES");
            else System.out.println("NO");
        }
    }
}
