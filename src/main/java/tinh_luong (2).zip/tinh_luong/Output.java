/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tinh_luong;

/**
 *
 * @author Nguyen Cong Van
 */
public class Output {
    String code, name, codeRoom, nameRoom;
    int salary;
    
    Output() {}
    
    public String toString() {
        return code + " " + name + " " + salary;
    }
}
