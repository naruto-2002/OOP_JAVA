/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quan_ly_kho_xang_dau;

import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Warehouse {
    String singleCode;
    int amount;
    
    Warehouse() {};
    
    void input(Scanner sc) {
        singleCode = sc.next();
        amount = sc.nextInt();
    }
    
    String Manufacturer() {
        String s = singleCode.substring(3);
        if(s.compareTo("BP") == 0) return "British Petro";
        else if(s.compareTo("ES") == 0) return "Esso";
        else if(s.compareTo("SH") == 0) return "Shell";
        else if(s.compareTo("CA") == 0) return "Castrol";
        return "Mobil";
    }
    
    int Price() {
        char s = singleCode.charAt(0);
        if(s == 'X') return 128000;
        else if(s == 'D') return 11200;
        return 9700;
    }
    
    int Tax() {
        char s = singleCode.charAt(0);
        if(s == 'X') return (int) (128000*0.03)*amount;
        else if(s == 'D') return (int) (11200*0.035)*amount;
        return (int) (9700*0.02)*amount;
    }
    
    int Money() {
        return amount*Price() + Tax();
    }
    
    public String toString() {
        return singleCode + " " + Manufacturer() + " " + Price() + " " + Tax() + " " + Money();
    }
}
