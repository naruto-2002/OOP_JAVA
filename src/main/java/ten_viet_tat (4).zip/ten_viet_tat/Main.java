/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ten_viet_tat;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 *
 * @author Nguyen Cong Van
 */
public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("DANHSACH.in"));
        int t = sc.nextInt();
        sc.nextLine();
        ArrayList<Teacher> res1 = new ArrayList<>();
        while(t-- > 0) {
            res1.add(new Teacher(sc));
        }
        ArrayList<Teacher> res2 = new ArrayList<>();
        int tt = sc.nextInt();
        while(tt-- > 0) {
            String s = sc.next();
            String[] ans = s.split("\\.");
            for(Teacher gv: res1) {
                if(gv.getSummary().compareTo(s) == 0) {
                    res2.add(gv);
                }else {
                    int cnt = 0;
                    for(String ss: ans) {
                        if(!gv.getSummary().contains(ss)) {
                            cnt += 1;
                        }
                    }
                    if(cnt == 1) {
                        res2.add(gv);
                    }
                }
            }
        }
        Collections.sort(res2);
        for(Teacher gv: res2) {
            System.out.println(gv);
        }
    }
    
}
